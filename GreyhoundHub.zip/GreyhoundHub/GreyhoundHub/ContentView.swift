//
//  ContentView.swift
//  GreyhoundHub
//
//  Created by Student on 11/2/23.
//

import SwiftUI
import Foundation


struct ContentView: View {
    @ObservedObject var postViewModel = PostViewModel()
    @State private var showingSheet = false
    @State private var isLoginViewPresented = false
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack {
                Text("GreyhoundHub")
                    .font(.system(size: 48))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.top, 40)
                
                Spacer()
                
                HStack {
                    Button(action: {
                        // Add action for "Worker" button here
                    }) {
                        Text("Worker")
                            .foregroundColor(.gray)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                            .frame(minHeight: 120)
                            .background(Color.mint)
                            .cornerRadius(10)
                    }
                    
                    Button(action: {
                        isLoginViewPresented = true
                    }) {
                        Text("Student")
                            .foregroundColor(.mint)
                            .font(.largeTitle)
                            .bold()
                            .padding()
                            .frame(minHeight: 120)
                            .background(Color.gray)
                            .cornerRadius(10)
                    }
                    .sheet(isPresented: $isLoginViewPresented) {
                        LoginView()
                    }
                }
                
                Spacer()
            }
        }
    }
}

struct LoginView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var isCreatingAccount = false
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.green, .mint],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack {
                Text("Login Page")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 40)
                Spacer()
                
                TextField("Username", text: $username)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Spacer()
                Button(action: {
                    // Handle login action here using the `username` and `password` values
                }) {
                    Text("Login")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                        .frame(maxWidth: 300)
                }
                .buttonStyle(.borderedProminent)
                
                Spacer()
                
                Button(action: {
                    isCreatingAccount = true
                }) {
                    Text("Create New Account")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(10)
                }
                .sheet(isPresented: $isCreatingAccount) {
                    CreateAccountView()
                }
            }
        }
    }
}

struct CreateAccountView: View {
    @State private var newUsername = ""
    @State private var newPassword = ""
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.mint, .green],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack {
                Text("Create Account")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 40)
                
                TextField("Username", text: $newUsername)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                SecureField("Password", text: $newPassword)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                
                Button(action: {
                    // Handle account creation action using the newUsername and newPassword values
                }) {
                    Text("Create Account")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(10)
                }
            }
        }
    }
}

class PostViewModel: ObservableObject {
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
